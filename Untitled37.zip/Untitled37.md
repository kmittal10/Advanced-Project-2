```python
import pandas as pd
import numpy as np
```

Importing temperature datasets


```python
data1=pd.read_excel('D:/New Volume/Sem3/Advanced project 2/New folder/Book2.xlsx', sheet_name='Min',parse_dates =["Date"], index_col ="Date")
data1.columns = [str(col) + '_min' for col in data1.columns]
data2=pd.read_excel('D:/New Volume/Sem3/Advanced project 2/New folder/Book2.xlsx', sheet_name='Avg',parse_dates =["Date"], index_col ="Date")
data2.columns = [str(col) + '_avg' for col in data2.columns]
data3=pd.read_excel('D:/New Volume/Sem3/Advanced project 2/New folder/Book2.xlsx', sheet_name='Max',parse_dates =["Date"], index_col ="Date")
data3.columns = [str(col) + '_max' for col in data3.columns]
```

Merging temp series


```python
from functools import reduce
dfs=[data1, data2, data3]
temp_merged = reduce(lambda left,right: pd.merge(left,right,on='Date'), dfs)
temp_merged.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_min</th>
      <th>Abidjan (CIV)_min</th>
      <th>Bas-Sassandra (CIV)_min</th>
      <th>Comoe (CIV)_min</th>
      <th>Denguele (CIV)_min</th>
      <th>Goh-Djiboua (CIV)_min</th>
      <th>Lacs (CIV)_min</th>
      <th>Lagunes (CIV)_min</th>
      <th>Montagnes (CIV)_min</th>
      <th>Sassandra-Marahoue (CIV)_min</th>
      <th>...</th>
      <th>Goh-Djiboua (CIV)_max</th>
      <th>Lacs (CIV)_max</th>
      <th>Lagunes (CIV)_max</th>
      <th>Montagnes (CIV)_max</th>
      <th>Sassandra-Marahoue (CIV)_max</th>
      <th>Savanes (CIV)_max</th>
      <th>Vallee du Bandama (CIV)_max</th>
      <th>Woroba (CIV)_max</th>
      <th>Yamoussoukro (CIV)_max</th>
      <th>Zanzan (CIV)_max</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2006-01-01</td>
      <td>16.8</td>
      <td>21.1</td>
      <td>22.1</td>
      <td>20.9</td>
      <td>14.2</td>
      <td>21.9</td>
      <td>20.5</td>
      <td>19.9</td>
      <td>16.5</td>
      <td>18.4</td>
      <td>...</td>
      <td>35.4</td>
      <td>37.8</td>
      <td>35.9</td>
      <td>34.7</td>
      <td>36.0</td>
      <td>36.3</td>
      <td>36.8</td>
      <td>36.0</td>
      <td>37.7</td>
      <td>36.5</td>
    </tr>
    <tr>
      <td>2006-02-01</td>
      <td>17.6</td>
      <td>23.5</td>
      <td>21.3</td>
      <td>21.4</td>
      <td>15.4</td>
      <td>21.5</td>
      <td>20.7</td>
      <td>21.9</td>
      <td>18.7</td>
      <td>20.2</td>
      <td>...</td>
      <td>36.6</td>
      <td>38.7</td>
      <td>36.8</td>
      <td>36.2</td>
      <td>38.0</td>
      <td>36.9</td>
      <td>39.1</td>
      <td>38.4</td>
      <td>38.9</td>
      <td>38.6</td>
    </tr>
    <tr>
      <td>2006-03-01</td>
      <td>18.2</td>
      <td>25.1</td>
      <td>21.8</td>
      <td>22.8</td>
      <td>16.2</td>
      <td>21.5</td>
      <td>20.2</td>
      <td>23.1</td>
      <td>18.0</td>
      <td>20.6</td>
      <td>...</td>
      <td>35.9</td>
      <td>38.4</td>
      <td>35.5</td>
      <td>36.2</td>
      <td>37.5</td>
      <td>38.0</td>
      <td>39.0</td>
      <td>39.0</td>
      <td>38.2</td>
      <td>39.8</td>
    </tr>
    <tr>
      <td>2006-04-01</td>
      <td>18.1</td>
      <td>25.2</td>
      <td>21.0</td>
      <td>22.6</td>
      <td>16.5</td>
      <td>22.1</td>
      <td>21.0</td>
      <td>22.7</td>
      <td>17.8</td>
      <td>20.7</td>
      <td>...</td>
      <td>35.7</td>
      <td>38.6</td>
      <td>35.0</td>
      <td>37.0</td>
      <td>38.2</td>
      <td>38.1</td>
      <td>39.9</td>
      <td>39.4</td>
      <td>38.4</td>
      <td>40.0</td>
    </tr>
    <tr>
      <td>2006-05-01</td>
      <td>19.2</td>
      <td>23.9</td>
      <td>22.5</td>
      <td>22.2</td>
      <td>15.2</td>
      <td>22.4</td>
      <td>21.8</td>
      <td>22.2</td>
      <td>19.7</td>
      <td>21.8</td>
      <td>...</td>
      <td>33.9</td>
      <td>39.0</td>
      <td>33.0</td>
      <td>36.8</td>
      <td>37.7</td>
      <td>38.6</td>
      <td>39.8</td>
      <td>40.0</td>
      <td>38.9</td>
      <td>40.6</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 45 columns</p>
</div>



Resampling temperature data weekely


```python
re_temp = temp_merged.resample('W').mean()
re_temp
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_min</th>
      <th>Abidjan (CIV)_min</th>
      <th>Bas-Sassandra (CIV)_min</th>
      <th>Comoe (CIV)_min</th>
      <th>Denguele (CIV)_min</th>
      <th>Goh-Djiboua (CIV)_min</th>
      <th>Lacs (CIV)_min</th>
      <th>Lagunes (CIV)_min</th>
      <th>Montagnes (CIV)_min</th>
      <th>Sassandra-Marahoue (CIV)_min</th>
      <th>...</th>
      <th>Goh-Djiboua (CIV)_max</th>
      <th>Lacs (CIV)_max</th>
      <th>Lagunes (CIV)_max</th>
      <th>Montagnes (CIV)_max</th>
      <th>Sassandra-Marahoue (CIV)_max</th>
      <th>Savanes (CIV)_max</th>
      <th>Vallee du Bandama (CIV)_max</th>
      <th>Woroba (CIV)_max</th>
      <th>Yamoussoukro (CIV)_max</th>
      <th>Zanzan (CIV)_max</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2006-01-01</td>
      <td>16.800000</td>
      <td>21.100000</td>
      <td>22.100000</td>
      <td>20.900000</td>
      <td>14.200000</td>
      <td>21.900000</td>
      <td>20.500000</td>
      <td>19.900000</td>
      <td>16.500000</td>
      <td>18.400000</td>
      <td>...</td>
      <td>35.400000</td>
      <td>37.800000</td>
      <td>35.900000</td>
      <td>34.700000</td>
      <td>36.000000</td>
      <td>36.300000</td>
      <td>36.800000</td>
      <td>36.000000</td>
      <td>37.700000</td>
      <td>36.500000</td>
    </tr>
    <tr>
      <td>2006-01-08</td>
      <td>22.371429</td>
      <td>24.385714</td>
      <td>22.428571</td>
      <td>22.957143</td>
      <td>22.142857</td>
      <td>22.300000</td>
      <td>22.442857</td>
      <td>22.657143</td>
      <td>21.528571</td>
      <td>22.285714</td>
      <td>...</td>
      <td>31.242857</td>
      <td>35.642857</td>
      <td>31.142857</td>
      <td>32.871429</td>
      <td>33.728571</td>
      <td>38.514286</td>
      <td>37.357143</td>
      <td>36.800000</td>
      <td>34.400000</td>
      <td>38.985714</td>
    </tr>
    <tr>
      <td>2006-01-15</td>
      <td>20.100000</td>
      <td>23.371429</td>
      <td>21.871429</td>
      <td>22.371429</td>
      <td>19.142857</td>
      <td>21.800000</td>
      <td>21.614286</td>
      <td>21.871429</td>
      <td>20.028571</td>
      <td>21.057143</td>
      <td>...</td>
      <td>33.400000</td>
      <td>36.614286</td>
      <td>32.528571</td>
      <td>33.557143</td>
      <td>35.171429</td>
      <td>35.614286</td>
      <td>36.585714</td>
      <td>36.057143</td>
      <td>36.557143</td>
      <td>36.514286</td>
    </tr>
    <tr>
      <td>2006-01-22</td>
      <td>19.971429</td>
      <td>23.142857</td>
      <td>22.214286</td>
      <td>22.114286</td>
      <td>17.300000</td>
      <td>21.985714</td>
      <td>21.842857</td>
      <td>21.985714</td>
      <td>19.985714</td>
      <td>22.014286</td>
      <td>...</td>
      <td>34.685714</td>
      <td>38.771429</td>
      <td>34.385714</td>
      <td>35.742857</td>
      <td>37.200000</td>
      <td>38.014286</td>
      <td>38.357143</td>
      <td>37.800000</td>
      <td>38.542857</td>
      <td>38.442857</td>
    </tr>
    <tr>
      <td>2006-01-29</td>
      <td>21.571429</td>
      <td>24.271429</td>
      <td>22.742857</td>
      <td>22.742857</td>
      <td>18.742857</td>
      <td>22.628571</td>
      <td>22.800000</td>
      <td>22.685714</td>
      <td>22.028571</td>
      <td>23.485714</td>
      <td>...</td>
      <td>35.700000</td>
      <td>39.928571</td>
      <td>35.014286</td>
      <td>36.157143</td>
      <td>37.785714</td>
      <td>39.657143</td>
      <td>40.300000</td>
      <td>40.842857</td>
      <td>39.128571</td>
      <td>41.142857</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>2018-12-09</td>
      <td>21.757143</td>
      <td>23.200000</td>
      <td>21.614286</td>
      <td>21.942857</td>
      <td>21.471429</td>
      <td>21.385714</td>
      <td>21.700000</td>
      <td>21.900000</td>
      <td>20.685714</td>
      <td>21.457143</td>
      <td>...</td>
      <td>31.228571</td>
      <td>34.342857</td>
      <td>30.471429</td>
      <td>31.414286</td>
      <td>33.257143</td>
      <td>34.171429</td>
      <td>34.414286</td>
      <td>33.771429</td>
      <td>33.942857</td>
      <td>33.985714</td>
    </tr>
    <tr>
      <td>2018-12-16</td>
      <td>19.271429</td>
      <td>22.671429</td>
      <td>21.442857</td>
      <td>21.542857</td>
      <td>17.885714</td>
      <td>21.357143</td>
      <td>20.328571</td>
      <td>21.800000</td>
      <td>18.500000</td>
      <td>19.414286</td>
      <td>...</td>
      <td>33.614286</td>
      <td>36.142857</td>
      <td>32.857143</td>
      <td>33.014286</td>
      <td>34.742857</td>
      <td>35.114286</td>
      <td>35.828571</td>
      <td>35.142857</td>
      <td>35.585714</td>
      <td>36.185714</td>
    </tr>
    <tr>
      <td>2018-12-23</td>
      <td>18.042857</td>
      <td>23.028571</td>
      <td>21.814286</td>
      <td>21.685714</td>
      <td>15.571429</td>
      <td>21.571429</td>
      <td>19.871429</td>
      <td>22.185714</td>
      <td>17.942857</td>
      <td>19.628571</td>
      <td>...</td>
      <td>34.600000</td>
      <td>36.685714</td>
      <td>33.642857</td>
      <td>34.442857</td>
      <td>36.342857</td>
      <td>35.357143</td>
      <td>36.757143</td>
      <td>36.428571</td>
      <td>36.285714</td>
      <td>36.342857</td>
    </tr>
    <tr>
      <td>2018-12-30</td>
      <td>16.414286</td>
      <td>22.157143</td>
      <td>20.557143</td>
      <td>18.900000</td>
      <td>15.285714</td>
      <td>19.657143</td>
      <td>17.314286</td>
      <td>20.000000</td>
      <td>15.185714</td>
      <td>16.400000</td>
      <td>...</td>
      <td>35.942857</td>
      <td>37.500000</td>
      <td>35.200000</td>
      <td>34.342857</td>
      <td>35.985714</td>
      <td>34.757143</td>
      <td>36.742857</td>
      <td>35.914286</td>
      <td>36.885714</td>
      <td>36.885714</td>
    </tr>
    <tr>
      <td>2019-01-06</td>
      <td>19.400000</td>
      <td>23.300000</td>
      <td>21.500000</td>
      <td>21.000000</td>
      <td>19.200000</td>
      <td>20.800000</td>
      <td>20.700000</td>
      <td>21.300000</td>
      <td>18.500000</td>
      <td>19.800000</td>
      <td>...</td>
      <td>36.400000</td>
      <td>37.900000</td>
      <td>36.300000</td>
      <td>35.100000</td>
      <td>37.000000</td>
      <td>36.600000</td>
      <td>38.100000</td>
      <td>37.100000</td>
      <td>37.500000</td>
      <td>36.800000</td>
    </tr>
  </tbody>
</table>
<p>680 rows × 45 columns</p>
</div>



IMporting production dataset and reindexing it on temperature data


```python
data_p=pd.read_excel('D:/New Volume/Sem3/Advanced project 2/New folder/Book2.xlsx', sheet_name='Prod',parse_dates =["Date"], index_col ="Date")
data_p.sort_values(by=['Date'], inplace=True)
data_p = data_p.resample('W').mean() 
prod_data=data_p.reindex(re_temp.index)
median2 = prod_data.ffill()
prod_data.fillna(median2, inplace=True)
prod_data=prod_data.replace(0).bfill()
prod_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prod</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2006-01-01</td>
      <td>715000.0</td>
    </tr>
    <tr>
      <td>2006-01-08</td>
      <td>715000.0</td>
    </tr>
    <tr>
      <td>2006-01-15</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>2006-01-22</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>2006-01-29</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>2018-12-09</td>
      <td>689000.0</td>
    </tr>
    <tr>
      <td>2018-12-16</td>
      <td>766000.0</td>
    </tr>
    <tr>
      <td>2018-12-23</td>
      <td>836000.0</td>
    </tr>
    <tr>
      <td>2018-12-30</td>
      <td>836000.0</td>
    </tr>
    <tr>
      <td>2019-01-06</td>
      <td>1051000.0</td>
    </tr>
  </tbody>
</table>
<p>680 rows × 1 columns</p>
</div>



Place the DataFrames side by side


```python
dfinal = pd.concat([re_temp, prod_data], axis=1)
dfinal
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_min</th>
      <th>Abidjan (CIV)_min</th>
      <th>Bas-Sassandra (CIV)_min</th>
      <th>Comoe (CIV)_min</th>
      <th>Denguele (CIV)_min</th>
      <th>Goh-Djiboua (CIV)_min</th>
      <th>Lacs (CIV)_min</th>
      <th>Lagunes (CIV)_min</th>
      <th>Montagnes (CIV)_min</th>
      <th>Sassandra-Marahoue (CIV)_min</th>
      <th>...</th>
      <th>Lacs (CIV)_max</th>
      <th>Lagunes (CIV)_max</th>
      <th>Montagnes (CIV)_max</th>
      <th>Sassandra-Marahoue (CIV)_max</th>
      <th>Savanes (CIV)_max</th>
      <th>Vallee du Bandama (CIV)_max</th>
      <th>Woroba (CIV)_max</th>
      <th>Yamoussoukro (CIV)_max</th>
      <th>Zanzan (CIV)_max</th>
      <th>Prod</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2006-01-01</td>
      <td>16.800000</td>
      <td>21.100000</td>
      <td>22.100000</td>
      <td>20.900000</td>
      <td>14.200000</td>
      <td>21.900000</td>
      <td>20.500000</td>
      <td>19.900000</td>
      <td>16.500000</td>
      <td>18.400000</td>
      <td>...</td>
      <td>37.800000</td>
      <td>35.900000</td>
      <td>34.700000</td>
      <td>36.000000</td>
      <td>36.300000</td>
      <td>36.800000</td>
      <td>36.000000</td>
      <td>37.700000</td>
      <td>36.500000</td>
      <td>715000.0</td>
    </tr>
    <tr>
      <td>2006-01-08</td>
      <td>22.371429</td>
      <td>24.385714</td>
      <td>22.428571</td>
      <td>22.957143</td>
      <td>22.142857</td>
      <td>22.300000</td>
      <td>22.442857</td>
      <td>22.657143</td>
      <td>21.528571</td>
      <td>22.285714</td>
      <td>...</td>
      <td>35.642857</td>
      <td>31.142857</td>
      <td>32.871429</td>
      <td>33.728571</td>
      <td>38.514286</td>
      <td>37.357143</td>
      <td>36.800000</td>
      <td>34.400000</td>
      <td>38.985714</td>
      <td>715000.0</td>
    </tr>
    <tr>
      <td>2006-01-15</td>
      <td>20.100000</td>
      <td>23.371429</td>
      <td>21.871429</td>
      <td>22.371429</td>
      <td>19.142857</td>
      <td>21.800000</td>
      <td>21.614286</td>
      <td>21.871429</td>
      <td>20.028571</td>
      <td>21.057143</td>
      <td>...</td>
      <td>36.614286</td>
      <td>32.528571</td>
      <td>33.557143</td>
      <td>35.171429</td>
      <td>35.614286</td>
      <td>36.585714</td>
      <td>36.057143</td>
      <td>36.557143</td>
      <td>36.514286</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>2006-01-22</td>
      <td>19.971429</td>
      <td>23.142857</td>
      <td>22.214286</td>
      <td>22.114286</td>
      <td>17.300000</td>
      <td>21.985714</td>
      <td>21.842857</td>
      <td>21.985714</td>
      <td>19.985714</td>
      <td>22.014286</td>
      <td>...</td>
      <td>38.771429</td>
      <td>34.385714</td>
      <td>35.742857</td>
      <td>37.200000</td>
      <td>38.014286</td>
      <td>38.357143</td>
      <td>37.800000</td>
      <td>38.542857</td>
      <td>38.442857</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>2006-01-29</td>
      <td>21.571429</td>
      <td>24.271429</td>
      <td>22.742857</td>
      <td>22.742857</td>
      <td>18.742857</td>
      <td>22.628571</td>
      <td>22.800000</td>
      <td>22.685714</td>
      <td>22.028571</td>
      <td>23.485714</td>
      <td>...</td>
      <td>39.928571</td>
      <td>35.014286</td>
      <td>36.157143</td>
      <td>37.785714</td>
      <td>39.657143</td>
      <td>40.300000</td>
      <td>40.842857</td>
      <td>39.128571</td>
      <td>41.142857</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>2018-12-09</td>
      <td>21.757143</td>
      <td>23.200000</td>
      <td>21.614286</td>
      <td>21.942857</td>
      <td>21.471429</td>
      <td>21.385714</td>
      <td>21.700000</td>
      <td>21.900000</td>
      <td>20.685714</td>
      <td>21.457143</td>
      <td>...</td>
      <td>34.342857</td>
      <td>30.471429</td>
      <td>31.414286</td>
      <td>33.257143</td>
      <td>34.171429</td>
      <td>34.414286</td>
      <td>33.771429</td>
      <td>33.942857</td>
      <td>33.985714</td>
      <td>689000.0</td>
    </tr>
    <tr>
      <td>2018-12-16</td>
      <td>19.271429</td>
      <td>22.671429</td>
      <td>21.442857</td>
      <td>21.542857</td>
      <td>17.885714</td>
      <td>21.357143</td>
      <td>20.328571</td>
      <td>21.800000</td>
      <td>18.500000</td>
      <td>19.414286</td>
      <td>...</td>
      <td>36.142857</td>
      <td>32.857143</td>
      <td>33.014286</td>
      <td>34.742857</td>
      <td>35.114286</td>
      <td>35.828571</td>
      <td>35.142857</td>
      <td>35.585714</td>
      <td>36.185714</td>
      <td>766000.0</td>
    </tr>
    <tr>
      <td>2018-12-23</td>
      <td>18.042857</td>
      <td>23.028571</td>
      <td>21.814286</td>
      <td>21.685714</td>
      <td>15.571429</td>
      <td>21.571429</td>
      <td>19.871429</td>
      <td>22.185714</td>
      <td>17.942857</td>
      <td>19.628571</td>
      <td>...</td>
      <td>36.685714</td>
      <td>33.642857</td>
      <td>34.442857</td>
      <td>36.342857</td>
      <td>35.357143</td>
      <td>36.757143</td>
      <td>36.428571</td>
      <td>36.285714</td>
      <td>36.342857</td>
      <td>836000.0</td>
    </tr>
    <tr>
      <td>2018-12-30</td>
      <td>16.414286</td>
      <td>22.157143</td>
      <td>20.557143</td>
      <td>18.900000</td>
      <td>15.285714</td>
      <td>19.657143</td>
      <td>17.314286</td>
      <td>20.000000</td>
      <td>15.185714</td>
      <td>16.400000</td>
      <td>...</td>
      <td>37.500000</td>
      <td>35.200000</td>
      <td>34.342857</td>
      <td>35.985714</td>
      <td>34.757143</td>
      <td>36.742857</td>
      <td>35.914286</td>
      <td>36.885714</td>
      <td>36.885714</td>
      <td>836000.0</td>
    </tr>
    <tr>
      <td>2019-01-06</td>
      <td>19.400000</td>
      <td>23.300000</td>
      <td>21.500000</td>
      <td>21.000000</td>
      <td>19.200000</td>
      <td>20.800000</td>
      <td>20.700000</td>
      <td>21.300000</td>
      <td>18.500000</td>
      <td>19.800000</td>
      <td>...</td>
      <td>37.900000</td>
      <td>36.300000</td>
      <td>35.100000</td>
      <td>37.000000</td>
      <td>36.600000</td>
      <td>38.100000</td>
      <td>37.100000</td>
      <td>37.500000</td>
      <td>36.800000</td>
      <td>1051000.0</td>
    </tr>
  </tbody>
</table>
<p>680 rows × 46 columns</p>
</div>



Feature eingineering, applying pca


```python
%matplotlib inline
import pandas as pd # for using pandas daraframe
import numpy as np # for som math operations
from sklearn.preprocessing import StandardScaler # for standardizing the Data
from sklearn.decomposition import PCA # for PCA calculation
import matplotlib.pyplot as plt # for plotting
```


```python
X = dfinal.values # getting all values as a matrix of dataframe 
sc = StandardScaler() # creating a StandardScaler object
X_std = sc.fit_transform(X) # standardizing the data
```


```python
pca = PCA()
X_pca = pca.fit(X_std)
```


```python
plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel('number of components')
plt.ylabel('cumulative explained variance')
```




    Text(0, 0.5, 'cumulative explained variance')




![png](output_15_1.png)



```python
pca = PCA(n_components = 0.99)
X_pca = pca.fit_transform(X_std) # this will fit and reduce dimensions
print(pca.n_components_)
```

    12
    


```python
n_pcs= pca.n_components_ # get number of component
# get the index of the most important feature on EACH component
most_important = [np.abs(pca.components_[i]).argmax() for i in range(n_pcs)]
initial_feature_names = dfinal.columns
# get the most important feature names
most_important_names = [initial_feature_names[most_important[i]] for i in range(n_pcs)]
```


```python
print(most_important_names)
```

    ["Cote D'Ivoire_avg", 'Woroba (CIV)_min', 'Bas-Sassandra (CIV)_min', 'Prod', 'Prod', 'Abidjan (CIV)_min', 'Bas-Sassandra (CIV)_avg', 'Denguele (CIV)_min', 'Yamoussoukro (CIV)_max', 'Abidjan (CIV)_min', 'Bas-Sassandra (CIV)_min', 'Comoe (CIV)_min']
    


```python
dfinal1=dfinal[["Cote D'Ivoire_avg", 'Woroba (CIV)_min', 'Bas-Sassandra (CIV)_min', 'Abidjan (CIV)_min', 'Bas-Sassandra (CIV)_avg', 'Denguele (CIV)_min', 'Yamoussoukro (CIV)_max', 'Abidjan (CIV)_min', 'Bas-Sassandra (CIV)_min', 'Comoe (CIV)_min','Prod','Prod']]
```


```python
dfinal1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_avg</th>
      <th>Woroba (CIV)_min</th>
      <th>Bas-Sassandra (CIV)_min</th>
      <th>Abidjan (CIV)_min</th>
      <th>Bas-Sassandra (CIV)_avg</th>
      <th>Denguele (CIV)_min</th>
      <th>Yamoussoukro (CIV)_max</th>
      <th>Abidjan (CIV)_min</th>
      <th>Bas-Sassandra (CIV)_min</th>
      <th>Comoe (CIV)_min</th>
      <th>Prod</th>
      <th>Prod</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2006-01-01</td>
      <td>26.400000</td>
      <td>11.800000</td>
      <td>22.100000</td>
      <td>21.100000</td>
      <td>28.300000</td>
      <td>14.200000</td>
      <td>37.700000</td>
      <td>21.100000</td>
      <td>22.100000</td>
      <td>20.900000</td>
      <td>715000.0</td>
      <td>715000.0</td>
    </tr>
    <tr>
      <td>2006-01-08</td>
      <td>28.800000</td>
      <td>22.385714</td>
      <td>22.428571</td>
      <td>24.385714</td>
      <td>26.157143</td>
      <td>22.142857</td>
      <td>34.400000</td>
      <td>24.385714</td>
      <td>22.428571</td>
      <td>22.957143</td>
      <td>715000.0</td>
      <td>715000.0</td>
    </tr>
    <tr>
      <td>2006-01-15</td>
      <td>27.528571</td>
      <td>18.728571</td>
      <td>21.871429</td>
      <td>23.371429</td>
      <td>26.885714</td>
      <td>19.142857</td>
      <td>36.557143</td>
      <td>23.371429</td>
      <td>21.871429</td>
      <td>22.371429</td>
      <td>750000.0</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>2006-01-22</td>
      <td>28.342857</td>
      <td>18.557143</td>
      <td>22.214286</td>
      <td>23.142857</td>
      <td>27.457143</td>
      <td>17.300000</td>
      <td>38.542857</td>
      <td>23.142857</td>
      <td>22.214286</td>
      <td>22.114286</td>
      <td>750000.0</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>2006-01-29</td>
      <td>29.914286</td>
      <td>22.000000</td>
      <td>22.742857</td>
      <td>24.271429</td>
      <td>28.285714</td>
      <td>18.742857</td>
      <td>39.128571</td>
      <td>24.271429</td>
      <td>22.742857</td>
      <td>22.742857</td>
      <td>750000.0</td>
      <td>750000.0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>2018-12-09</td>
      <td>27.342857</td>
      <td>21.528571</td>
      <td>21.614286</td>
      <td>23.200000</td>
      <td>25.557143</td>
      <td>21.471429</td>
      <td>33.942857</td>
      <td>23.200000</td>
      <td>21.614286</td>
      <td>21.942857</td>
      <td>689000.0</td>
      <td>689000.0</td>
    </tr>
    <tr>
      <td>2018-12-16</td>
      <td>26.942857</td>
      <td>17.214286</td>
      <td>21.442857</td>
      <td>22.671429</td>
      <td>26.914286</td>
      <td>17.885714</td>
      <td>35.585714</td>
      <td>22.671429</td>
      <td>21.442857</td>
      <td>21.542857</td>
      <td>766000.0</td>
      <td>766000.0</td>
    </tr>
    <tr>
      <td>2018-12-23</td>
      <td>26.671429</td>
      <td>14.328571</td>
      <td>21.814286</td>
      <td>23.028571</td>
      <td>27.585714</td>
      <td>15.571429</td>
      <td>36.285714</td>
      <td>23.028571</td>
      <td>21.814286</td>
      <td>21.685714</td>
      <td>836000.0</td>
      <td>836000.0</td>
    </tr>
    <tr>
      <td>2018-12-30</td>
      <td>26.028571</td>
      <td>13.400000</td>
      <td>20.557143</td>
      <td>22.157143</td>
      <td>27.671429</td>
      <td>15.285714</td>
      <td>36.885714</td>
      <td>22.157143</td>
      <td>20.557143</td>
      <td>18.900000</td>
      <td>836000.0</td>
      <td>836000.0</td>
    </tr>
    <tr>
      <td>2019-01-06</td>
      <td>28.000000</td>
      <td>17.800000</td>
      <td>21.500000</td>
      <td>23.300000</td>
      <td>28.200000</td>
      <td>19.200000</td>
      <td>37.500000</td>
      <td>23.300000</td>
      <td>21.500000</td>
      <td>21.000000</td>
      <td>1051000.0</td>
      <td>1051000.0</td>
    </tr>
  </tbody>
</table>
<p>680 rows × 12 columns</p>
</div>



Remove duplicate columns


```python
dfinal1= dfinal1.loc[:,~dfinal1.columns.duplicated()]
dfinal1.shape
```




    (680, 9)




```python
dfinal1.isnull().sum()
```




    Cote D'Ivoire_avg          0
    Woroba (CIV)_min           0
    Bas-Sassandra (CIV)_min    0
    Abidjan (CIV)_min          0
    Bas-Sassandra (CIV)_avg    0
    Denguele (CIV)_min         0
    Yamoussoukro (CIV)_max     0
    Comoe (CIV)_min            0
    Prod                       0
    dtype: int64



Visualizing the series using matplotlib and seaborn


```python
import matplotlib.pyplot as plt
import seaborn as sns
# Use seaborn style defaults and set the default figure size
sns.set(rc={'figure.figsize':(11, 4)})
fig, axes = plt.subplots(nrows=4, ncols=2, dpi=120, figsize=(12,8))
for i, ax in enumerate(axes.flatten()):
    data = dfinal1[dfinal1.columns[i]]
    ax.plot(data, linewidth=0.5)
```


![png](output_25_0.png)



```python
cols_plot = ["Cote D'Ivoire_avg",'Woroba (CIV)_min','Bas-Sassandra (CIV)_min','Abidjan (CIV)_min','Bas-Sassandra (CIV)_avg',
'Denguele (CIV)_min','Yamoussoukro (CIV)_max','Comoe (CIV)_min']
axes = dfinal1[cols_plot].plot(marker='.', alpha=0.5, linestyle='None', figsize=(12, 19), subplots=True)
for ax in axes:
    ax.set_ylabel('Temp')
```


![png](output_26_0.png)



```python
plt.plot(dfinal1['Prod'])
plt.show()
```


![png](output_27_0.png)


Granger casuality test


```python
from statsmodels.tsa.stattools import grangercausalitytests
maxlag=12
test = 'ssr_chi2test'
def grangers_causation_matrix(data, variables, test='ssr_chi2test', verbose=False):    
    """Check Granger Causality of all possible combinations of the Time series.
    The rows are the response variable, columns are predictors. The values in the table 
    are the P-Values. P-Values lesser than the significance level (0.05), implies 
    the Null Hypothesis that the coefficients of the corresponding past values is 
    zero, that is, the X does not cause Y can be rejected.

    data      : pandas dataframe containing the time series variables
    variables : list containing names of the time series variables.
    """
    df = pd.DataFrame(np.zeros((len(variables), len(variables))), columns=variables, index=variables)
    for c in df.columns:
        for r in df.index:
            test_result = grangercausalitytests(data[[r, c]], maxlag=maxlag, verbose=False)
            p_values = [round(test_result[i+1][0][test][1],4) for i in range(maxlag)]
            if verbose: print(f'Y = {r}, X = {c}, P Values = {p_values}')
            min_p_value = np.min(p_values)
            df.loc[r, c] = min_p_value
    df.columns = [var + '_x' for var in variables]
    df.index = [var + '_y' for var in variables]
    return df

grangers_causation_matrix(dfinal1, variables = dfinal1.columns)      
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_avg_x</th>
      <th>Woroba (CIV)_min_x</th>
      <th>Bas-Sassandra (CIV)_min_x</th>
      <th>Abidjan (CIV)_min_x</th>
      <th>Bas-Sassandra (CIV)_avg_x</th>
      <th>Denguele (CIV)_min_x</th>
      <th>Yamoussoukro (CIV)_max_x</th>
      <th>Comoe (CIV)_min_x</th>
      <th>Prod_x</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Cote D'Ivoire_avg_y</td>
      <td>1.0</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Woroba (CIV)_min_y</td>
      <td>0.0</td>
      <td>1.0000</td>
      <td>0.0003</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0074</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Bas-Sassandra (CIV)_min_y</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>1.0000</td>
      <td>0.0083</td>
      <td>0.0003</td>
      <td>0.0000</td>
      <td>0.0002</td>
      <td>0.0059</td>
      <td>0.0001</td>
    </tr>
    <tr>
      <td>Abidjan (CIV)_min_y</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>0.0202</td>
      <td>1.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Bas-Sassandra (CIV)_avg_y</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>1.0000</td>
      <td>0.0000</td>
      <td>0.0034</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Denguele (CIV)_min_y</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>0.0320</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>1.0000</td>
      <td>0.0000</td>
      <td>0.1634</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Yamoussoukro (CIV)_max_y</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>1.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Comoe (CIV)_min_y</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>0.3911</td>
      <td>0.0002</td>
      <td>0.0001</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>1.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <td>Prod_y</td>
      <td>0.0</td>
      <td>0.3328</td>
      <td>0.1466</td>
      <td>0.0237</td>
      <td>0.0000</td>
      <td>0.5532</td>
      <td>0.0000</td>
      <td>0.2421</td>
      <td>1.0000</td>
    </tr>
  </tbody>
</table>
</div>



ADF test for checking if series are stationery or not


```python
def adfuller_test(series, signif=0.05, name='', verbose=False):
    r = adfuller(series, autolag='AIC')
    output = {'test_statistic':round(r[0], 4), 'pvalue':round(r[1], 4),'n_lags':round(r[2], 4),'n_obs':r[3]}
    p_value = output['pvalue']
    def adjust(val, length= 6): return str(val).ljust(length)
# Print Summary
    print(f' Augmented Dickey-Fuller Test on "{name}"', "\n ", '-'*47)
    print(f' Null Hypothesis: Data has unit root. Non-Stationary.')
    print(f' Significance Level = {signif}')
    print(f' Test Statistic = {output["test_statistic"]}')
    print(f' No. Lags Chosen = {output["n_lags"]}')
    for key,val in r[4].items():
        print(f' Critical value {adjust(key)} = {round(val, 3)}')
    if p_value <= signif:
        print(f" => P-Value = {p_value}. Rejecting Null Hypothesis.")
        print(f" => Series is Stationary.")
    else:
        print(f" => P-Value = {p_value}. Weak evidence to reject the Null Hypothesis.")
        print(f" => Series is Non-Stationary.")
```


```python
import statsmodels
from statsmodels.tsa.stattools import adfuller
for name, column in dfinal1.iteritems():
    adfuller_test(column, name=column.name)
    print('\n')
```

     Augmented Dickey-Fuller Test on "Cote D'Ivoire_avg" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -6.1095
     No. Lags Chosen = 19
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Woroba (CIV)_min" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -6.5917
     No. Lags Chosen = 14
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Bas-Sassandra (CIV)_min" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -7.1965
     No. Lags Chosen = 3
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Abidjan (CIV)_min" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -6.0175
     No. Lags Chosen = 9
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Bas-Sassandra (CIV)_avg" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -8.476
     No. Lags Chosen = 20
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Denguele (CIV)_min" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -5.556
     No. Lags Chosen = 18
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Yamoussoukro (CIV)_max" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -7.7676
     No. Lags Chosen = 20
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Comoe (CIV)_min" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -7.2139
     No. Lags Chosen = 7
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
     Augmented Dickey-Fuller Test on "Prod" 
      -----------------------------------------------
     Null Hypothesis: Data has unit root. Non-Stationary.
     Significance Level = 0.05
     Test Statistic = -6.0856
     No. Lags Chosen = 0
     Critical value 1%     = -3.44
     Critical value 5%     = -2.866
     Critical value 10%    = -2.569
     => P-Value = 0.0. Rejecting Null Hypothesis.
     => Series is Stationary.
    
    
    


```python
#creating the train and validation set
train = dfinal1[:int(0.8*(len(dfinal1)))]
valid = dfinal1[int(0.8*(len(dfinal1))):]

```


```python
print(train.shape)
print(valid.shape)
```

    (544, 9)
    (136, 9)
    

Selecting order(p) for VAR model


```python
from statsmodels.tsa.vector_ar.var_model import VAR
model = VAR(train)
for i in [1,2,3,4,5,6,7,8,9,10,11,12]:
    result = model.fit(i)
    print('Lag Order =', i)
    print('AIC : ', result.aic)
    print('BIC : ', result.bic)
    print('FPE : ', result.fpe)
    print('HQIC: ', result.hqic, '\n')
```

    Lag Order = 1
    AIC :  16.763422968476526
    BIC :  17.475651032553973
    FPE :  19066824.621228237
    HQIC:  17.041906070131777 
    
    Lag Order = 2
    AIC :  16.759855026265654
    BIC :  18.115003524874844
    FPE :  19003119.149545014
    HQIC:  17.289764416535117 
    
    Lag Order = 3
    AIC :  16.736780115168564
    BIC :  18.73667227463125
    FPE :  18580315.701626424
    HQIC:  17.51886936173121 
    
    Lag Order = 4
    AIC :  15.722247626297317
    BIC :  18.36871526235828
    FPE :  6744130.713308825
    HQIC:  16.757273916228346 
    
    Lag Order = 5
    AIC :  15.439354286678542
    BIC :  18.734237860623487
    FPE :  5091587.560197424
    HQIC:  16.72807845024652 
    
    Lag Order = 6
    AIC :  15.463386326520784
    BIC :  19.408535001762576
    FPE :  5229558.082109138
    HQIC:  17.00657286118317 
    
    Lag Order = 7
    AIC :  15.5469346853806
    BIC :  20.1442063845186
    FPE :  5706858.203374935
    HQIC:  17.345351779979662 
    
    Lag Order = 8
    AIC :  15.421389438499622
    BIC :  20.67265090085693
    FPE :  5059194.423762275
    HQIC:  17.475808997660803 
    
    Lag Order = 9
    AIC :  15.307694648929694
    BIC :  21.214821488573158
    FPE :  4545317.9087079335
    HQIC:  17.618892317664432 
    
    Lag Order = 10
    AIC :  15.390264809899225
    BIC :  21.955141574147166
    FPE :  4977737.342131753
    HQIC:  17.95901999841433 
    
    Lag Order = 11
    AIC :  15.532426524327782
    BIC :  22.75694675275041
    FPE :  5797341.900314656
    HQIC:  18.359522433043466 
    
    Lag Order = 12
    AIC :  15.390051190460953
    BIC :  23.276117474378534
    FPE :  5091060.754493098
    HQIC:  18.476274835239625 
    
    


```python
x = model.select_order(maxlags=10)
x.summary()
```




<table class="simpletable">
<caption>VAR Order Selection (* highlights the minimums)</caption>
<tr>
   <td></td>      <th>AIC</th>         <th>BIC</th>         <th>FPE</th>        <th>HQIC</th>    
</tr>
<tr>
  <th>0</th>  <td>     19.28</td>  <td>     19.35</td>  <td> 2.364e+08</td>  <td>     19.31</td> 
</tr>
<tr>
  <th>1</th>  <td>     16.71</td>  <td>     17.43*</td> <td> 1.807e+07</td>  <td>     16.99</td> 
</tr>
<tr>
  <th>2</th>  <td>     16.72</td>  <td>     18.09</td>  <td> 1.818e+07</td>  <td>     17.25</td> 
</tr>
<tr>
  <th>3</th>  <td>     16.69</td>  <td>     18.71</td>  <td> 1.769e+07</td>  <td>     17.48</td> 
</tr>
<tr>
  <th>4</th>  <td>     15.66</td>  <td>     18.33</td>  <td> 6.348e+06</td>  <td>     16.71*</td>
</tr>
<tr>
  <th>5</th>  <td>     15.43</td>  <td>     18.75</td>  <td> 5.046e+06</td>  <td>     16.73</td> 
</tr>
<tr>
  <th>6</th>  <td>     15.44</td>  <td>     19.41</td>  <td> 5.117e+06</td>  <td>     16.99</td> 
</tr>
<tr>
  <th>7</th>  <td>     15.51</td>  <td>     20.13</td>  <td> 5.514e+06</td>  <td>     17.32</td> 
</tr>
<tr>
  <th>8</th>  <td>     15.39</td>  <td>     20.65</td>  <td> 4.892e+06</td>  <td>     17.45</td> 
</tr>
<tr>
  <th>9</th>  <td>     15.31*</td> <td>     21.22</td>  <td> 4.553e+06*</td> <td>     17.62</td> 
</tr>
<tr>
  <th>10</th> <td>     15.39</td>  <td>     21.96</td>  <td> 4.978e+06</td>  <td>     17.96</td> 
</tr>
</table>



Training the VAR Model of Selected Order(p)


```python
from statsmodels.tsa.vector_ar.var_model import VAR

model = VAR(endog=train)
results = model.fit(5)

print(results.summary())
# make prediction on validation
#prediction = results.forecast(results.y, steps=len(valid))
```

      Summary of Regression Results   
    ==================================
    Model:                         VAR
    Method:                        OLS
    Date:           Sun, 31, May, 2020
    Time:                     14:48:44
    --------------------------------------------------------------------
    No. of Equations:         9.00000    BIC:                    18.7342
    Nobs:                     539.000    HQIC:                   16.7281
    Log likelihood:          -10630.2    FPE:                5.09159e+06
    AIC:                      15.4394    Det(Omega_mle):     2.43640e+06
    --------------------------------------------------------------------
    Results for equation Cote D'Ivoire_avg
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              2.155875         2.890194            0.746           0.456
    L1.Cote D'Ivoire_avg              -0.090765         0.176135           -0.515           0.606
    L1.Woroba (CIV)_min                0.009557         0.083746            0.114           0.909
    L1.Bas-Sassandra (CIV)_min         0.068446         0.165958            0.412           0.680
    L1.Abidjan (CIV)_min               0.041761         0.152863            0.273           0.785
    L1.Bas-Sassandra (CIV)_avg        -0.034929         0.139496           -0.250           0.802
    L1.Denguele (CIV)_min              0.168543         0.072905            2.312           0.021
    L1.Yamoussoukro (CIV)_max          0.071169         0.069898            1.018           0.309
    L1.Comoe (CIV)_min                 0.058829         0.158486            0.371           0.710
    L1.Prod                           -0.000001         0.000000           -2.826           0.005
    L2.Cote D'Ivoire_avg               0.021680         0.169124            0.128           0.898
    L2.Woroba (CIV)_min                0.050592         0.080418            0.629           0.529
    L2.Bas-Sassandra (CIV)_min         0.065005         0.163594            0.397           0.691
    L2.Abidjan (CIV)_min              -0.251054         0.153159           -1.639           0.101
    L2.Bas-Sassandra (CIV)_avg        -0.109456         0.136861           -0.800           0.424
    L2.Denguele (CIV)_min             -0.030028         0.072092           -0.417           0.677
    L2.Yamoussoukro (CIV)_max          0.044451         0.069779            0.637           0.524
    L2.Comoe (CIV)_min                 0.067968         0.159158            0.427           0.669
    L2.Prod                            0.000000         0.000000            0.946           0.344
    L3.Cote D'Ivoire_avg              -0.091977         0.168361           -0.546           0.585
    L3.Woroba (CIV)_min                0.206635         0.080193            2.577           0.010
    L3.Bas-Sassandra (CIV)_min        -0.186656         0.165031           -1.131           0.258
    L3.Abidjan (CIV)_min               0.152793         0.154954            0.986           0.324
    L3.Bas-Sassandra (CIV)_avg         0.181786         0.135689            1.340           0.180
    L3.Denguele (CIV)_min             -0.241965         0.071761           -3.372           0.001
    L3.Yamoussoukro (CIV)_max          0.023313         0.069445            0.336           0.737
    L3.Comoe (CIV)_min                -0.067096         0.159917           -0.420           0.675
    L3.Prod                           -0.000000         0.000000           -0.570           0.569
    L4.Cote D'Ivoire_avg               0.195438         0.168062            1.163           0.245
    L4.Woroba (CIV)_min                0.095385         0.080442            1.186           0.236
    L4.Bas-Sassandra (CIV)_min        -0.065418         0.163931           -0.399           0.690
    L4.Abidjan (CIV)_min               0.228571         0.152033            1.503           0.133
    L4.Bas-Sassandra (CIV)_avg         0.128642         0.137064            0.939           0.348
    L4.Denguele (CIV)_min              0.099079         0.072781            1.361           0.173
    L4.Yamoussoukro (CIV)_max          0.110790         0.069361            1.597           0.110
    L4.Comoe (CIV)_min                -0.235535         0.160561           -1.467           0.142
    L4.Prod                            0.000000         0.000000            0.386           0.700
    L5.Cote D'Ivoire_avg              -0.413154         0.170834           -2.418           0.016
    L5.Woroba (CIV)_min                0.070357         0.078928            0.891           0.373
    L5.Bas-Sassandra (CIV)_min        -0.120130         0.164963           -0.728           0.466
    L5.Abidjan (CIV)_min              -0.078764         0.149292           -0.528           0.598
    L5.Bas-Sassandra (CIV)_avg         0.512745         0.138053            3.714           0.000
    L5.Denguele (CIV)_min             -0.116370         0.070318           -1.655           0.098
    L5.Yamoussoukro (CIV)_max          0.161223         0.069062            2.334           0.020
    L5.Comoe (CIV)_min                 0.200044         0.160723            1.245           0.213
    L5.Prod                            0.000000         0.000000            1.137           0.256
    =============================================================================================
    
    Results for equation Woroba (CIV)_min
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              3.540208         4.220023            0.839           0.402
    L1.Cote D'Ivoire_avg              -0.348539         0.257178           -1.355           0.175
    L1.Woroba (CIV)_min                0.348401         0.122278            2.849           0.004
    L1.Bas-Sassandra (CIV)_min         0.183837         0.242317            0.759           0.448
    L1.Abidjan (CIV)_min               0.104305         0.223198            0.467           0.640
    L1.Bas-Sassandra (CIV)_avg         0.105133         0.203681            0.516           0.606
    L1.Denguele (CIV)_min              0.101352         0.106450            0.952           0.341
    L1.Yamoussoukro (CIV)_max          0.134141         0.102059            1.314           0.189
    L1.Comoe (CIV)_min                -0.115173         0.231408           -0.498           0.619
    L1.Prod                           -0.000000         0.000000           -0.346           0.729
    L2.Cote D'Ivoire_avg              -0.036152         0.246941           -0.146           0.884
    L2.Woroba (CIV)_min                0.181416         0.117419            1.545           0.122
    L2.Bas-Sassandra (CIV)_min        -0.058029         0.238867           -0.243           0.808
    L2.Abidjan (CIV)_min              -0.526957         0.223630           -2.356           0.018
    L2.Bas-Sassandra (CIV)_avg         0.095234         0.199833            0.477           0.634
    L2.Denguele (CIV)_min             -0.224941         0.105263           -2.137           0.033
    L2.Yamoussoukro (CIV)_max          0.048204         0.101886            0.473           0.636
    L2.Comoe (CIV)_min                 0.323234         0.232389            1.391           0.164
    L2.Prod                            0.000001         0.000000            1.362           0.173
    L3.Cote D'Ivoire_avg              -0.063874         0.245827           -0.260           0.795
    L3.Woroba (CIV)_min                0.164088         0.117091            1.401           0.161
    L3.Bas-Sassandra (CIV)_min        -0.254849         0.240964           -1.058           0.290
    L3.Abidjan (CIV)_min               0.266769         0.226251            1.179           0.238
    L3.Bas-Sassandra (CIV)_avg         0.260267         0.198122            1.314           0.189
    L3.Denguele (CIV)_min             -0.057862         0.104780           -0.552           0.581
    L3.Yamoussoukro (CIV)_max          0.050450         0.101398            0.498           0.619
    L3.Comoe (CIV)_min                -0.184152         0.233498           -0.789           0.430
    L3.Prod                           -0.000001         0.000000           -1.076           0.282
    L4.Cote D'Ivoire_avg              -0.301343         0.245390           -1.228           0.219
    L4.Woroba (CIV)_min                0.363554         0.117455            3.095           0.002
    L4.Bas-Sassandra (CIV)_min        -0.511193         0.239358           -2.136           0.033
    L4.Abidjan (CIV)_min              -0.118609         0.221986           -0.534           0.593
    L4.Bas-Sassandra (CIV)_avg        -0.049383         0.200130           -0.247           0.805
    L4.Denguele (CIV)_min              0.097906         0.106269            0.921           0.357
    L4.Yamoussoukro (CIV)_max          0.139255         0.101275            1.375           0.169
    L4.Comoe (CIV)_min                 0.415816         0.234438            1.774           0.076
    L4.Prod                            0.000000         0.000000            0.609           0.543
    L5.Cote D'Ivoire_avg               0.005189         0.249438            0.021           0.983
    L5.Woroba (CIV)_min               -0.178764         0.115244           -1.551           0.121
    L5.Bas-Sassandra (CIV)_min        -0.395921         0.240865           -1.644           0.100
    L5.Abidjan (CIV)_min              -0.070273         0.217984           -0.322           0.747
    L5.Bas-Sassandra (CIV)_avg         0.066280         0.201573            0.329           0.742
    L5.Denguele (CIV)_min              0.215721         0.102673            2.101           0.036
    L5.Yamoussoukro (CIV)_max          0.084117         0.100839            0.834           0.404
    L5.Comoe (CIV)_min                 0.372528         0.234674            1.587           0.112
    L5.Prod                            0.000001         0.000000            2.357           0.018
    =============================================================================================
    
    Results for equation Bas-Sassandra (CIV)_min
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              9.233226         1.934667            4.773           0.000
    L1.Cote D'Ivoire_avg              -0.075055         0.117903           -0.637           0.524
    L1.Woroba (CIV)_min                0.022265         0.056058            0.397           0.691
    L1.Bas-Sassandra (CIV)_min         0.055275         0.111090            0.498           0.619
    L1.Abidjan (CIV)_min              -0.060069         0.102325           -0.587           0.557
    L1.Bas-Sassandra (CIV)_avg         0.025419         0.093377            0.272           0.785
    L1.Denguele (CIV)_min              0.015778         0.048802            0.323           0.746
    L1.Yamoussoukro (CIV)_max          0.046897         0.046789            1.002           0.316
    L1.Comoe (CIV)_min                 0.253295         0.106089            2.388           0.017
    L1.Prod                           -0.000000         0.000000           -1.482           0.138
    L2.Cote D'Ivoire_avg               0.003665         0.113210            0.032           0.974
    L2.Woroba (CIV)_min                0.022131         0.053831            0.411           0.681
    L2.Bas-Sassandra (CIV)_min         0.041977         0.109509            0.383           0.701
    L2.Abidjan (CIV)_min              -0.204062         0.102523           -1.990           0.047
    L2.Bas-Sassandra (CIV)_avg        -0.073382         0.091614           -0.801           0.423
    L2.Denguele (CIV)_min             -0.011820         0.048258           -0.245           0.807
    L2.Yamoussoukro (CIV)_max          0.042570         0.046710            0.911           0.362
    L2.Comoe (CIV)_min                 0.093699         0.106539            0.879           0.379
    L2.Prod                            0.000000         0.000000            1.110           0.267
    L3.Cote D'Ivoire_avg              -0.035970         0.112699           -0.319           0.750
    L3.Woroba (CIV)_min                0.136755         0.053680            2.548           0.011
    L3.Bas-Sassandra (CIV)_min        -0.118846         0.110470           -1.076           0.282
    L3.Abidjan (CIV)_min               0.092254         0.103725            0.889           0.374
    L3.Bas-Sassandra (CIV)_avg         0.027870         0.090829            0.307           0.759
    L3.Denguele (CIV)_min             -0.092562         0.048036           -1.927           0.054
    L3.Yamoussoukro (CIV)_max          0.052327         0.046486            1.126           0.260
    L3.Comoe (CIV)_min                -0.073548         0.107047           -0.687           0.492
    L3.Prod                           -0.000000         0.000000           -0.634           0.526
    L4.Cote D'Ivoire_avg              -0.287337         0.112499           -2.554           0.011
    L4.Woroba (CIV)_min                0.091782         0.053847            1.704           0.088
    L4.Bas-Sassandra (CIV)_min         0.231293         0.109734            2.108           0.035
    L4.Abidjan (CIV)_min               0.023044         0.101769            0.226           0.821
    L4.Bas-Sassandra (CIV)_avg         0.141871         0.091750            1.546           0.122
    L4.Denguele (CIV)_min              0.126949         0.048719            2.606           0.009
    L4.Yamoussoukro (CIV)_max          0.101957         0.046429            2.196           0.028
    L4.Comoe (CIV)_min                -0.122776         0.107478           -1.142           0.253
    L4.Prod                            0.000000         0.000000            0.306           0.759
    L5.Cote D'Ivoire_avg              -0.152768         0.114355           -1.336           0.182
    L5.Woroba (CIV)_min                0.001404         0.052833            0.027           0.979
    L5.Bas-Sassandra (CIV)_min         0.043148         0.110424            0.391           0.696
    L5.Abidjan (CIV)_min               0.001806         0.099935            0.018           0.986
    L5.Bas-Sassandra (CIV)_avg         0.020245         0.092411            0.219           0.827
    L5.Denguele (CIV)_min              0.034810         0.047070            0.740           0.460
    L5.Yamoussoukro (CIV)_max          0.069208         0.046230            1.497           0.134
    L5.Comoe (CIV)_min                 0.026830         0.107586            0.249           0.803
    L5.Prod                           -0.000000         0.000000           -0.023           0.981
    =============================================================================================
    
    Results for equation Abidjan (CIV)_min
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              9.534222         2.218301            4.298           0.000
    L1.Cote D'Ivoire_avg              -0.034629         0.135189           -0.256           0.798
    L1.Woroba (CIV)_min               -0.010393         0.064277           -0.162           0.872
    L1.Bas-Sassandra (CIV)_min        -0.070629         0.127377           -0.554           0.579
    L1.Abidjan (CIV)_min               0.161533         0.117326            1.377           0.169
    L1.Bas-Sassandra (CIV)_avg         0.009748         0.107067            0.091           0.927
    L1.Denguele (CIV)_min              0.059791         0.055957            1.069           0.285
    L1.Yamoussoukro (CIV)_max          0.005285         0.053648            0.099           0.922
    L1.Comoe (CIV)_min                 0.169693         0.121642            1.395           0.163
    L1.Prod                           -0.000000         0.000000           -2.036           0.042
    L2.Cote D'Ivoire_avg              -0.045697         0.129807           -0.352           0.725
    L2.Woroba (CIV)_min                0.019355         0.061723            0.314           0.754
    L2.Bas-Sassandra (CIV)_min        -0.178236         0.125563           -1.419           0.156
    L2.Abidjan (CIV)_min              -0.080856         0.117554           -0.688           0.492
    L2.Bas-Sassandra (CIV)_avg        -0.137924         0.105045           -1.313           0.189
    L2.Denguele (CIV)_min             -0.013131         0.055333           -0.237           0.812
    L2.Yamoussoukro (CIV)_max          0.065896         0.053557            1.230           0.219
    L2.Comoe (CIV)_min                 0.213691         0.122158            1.749           0.080
    L2.Prod                            0.000000         0.000000            0.922           0.357
    L3.Cote D'Ivoire_avg              -0.002303         0.129222           -0.018           0.986
    L3.Woroba (CIV)_min                0.166967         0.061550            2.713           0.007
    L3.Bas-Sassandra (CIV)_min        -0.137932         0.126666           -1.089           0.276
    L3.Abidjan (CIV)_min               0.129734         0.118931            1.091           0.275
    L3.Bas-Sassandra (CIV)_avg        -0.001141         0.104145           -0.011           0.991
    L3.Denguele (CIV)_min             -0.169586         0.055079           -3.079           0.002
    L3.Yamoussoukro (CIV)_max          0.041215         0.053301            0.773           0.439
    L3.Comoe (CIV)_min                -0.092999         0.122741           -0.758           0.449
    L3.Prod                           -0.000000         0.000000           -0.457           0.647
    L4.Cote D'Ivoire_avg              -0.211540         0.128992           -1.640           0.101
    L4.Woroba (CIV)_min                0.082424         0.061741            1.335           0.182
    L4.Bas-Sassandra (CIV)_min        -0.014033         0.125821           -0.112           0.911
    L4.Abidjan (CIV)_min               0.227806         0.116689            1.952           0.051
    L4.Bas-Sassandra (CIV)_avg         0.195344         0.105201            1.857           0.063
    L4.Denguele (CIV)_min              0.147926         0.055862            2.648           0.008
    L4.Yamoussoukro (CIV)_max          0.096816         0.053236            1.819           0.069
    L4.Comoe (CIV)_min                -0.140762         0.123235           -1.142           0.253
    L4.Prod                            0.000000         0.000000            0.157           0.875
    L5.Cote D'Ivoire_avg              -0.170423         0.131120           -1.300           0.194
    L5.Woroba (CIV)_min                0.000296         0.060579            0.005           0.996
    L5.Bas-Sassandra (CIV)_min        -0.000546         0.126613           -0.004           0.997
    L5.Abidjan (CIV)_min               0.005550         0.114586            0.048           0.961
    L5.Bas-Sassandra (CIV)_avg         0.093542         0.105959            0.883           0.377
    L5.Denguele (CIV)_min             -0.022149         0.053971           -0.410           0.682
    L5.Yamoussoukro (CIV)_max          0.098214         0.053007            1.853           0.064
    L5.Comoe (CIV)_min                 0.074265         0.123359            0.602           0.547
    L5.Prod                           -0.000000         0.000000           -0.105           0.916
    =============================================================================================
    
    Results for equation Bas-Sassandra (CIV)_avg
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              6.162937         2.068412            2.980           0.003
    L1.Cote D'Ivoire_avg              -0.142192         0.126054           -1.128           0.259
    L1.Woroba (CIV)_min               -0.049918         0.059934           -0.833           0.405
    L1.Bas-Sassandra (CIV)_min        -0.046680         0.118770           -0.393           0.694
    L1.Abidjan (CIV)_min              -0.059119         0.109399           -0.540           0.589
    L1.Bas-Sassandra (CIV)_avg         0.193039         0.099833            1.934           0.053
    L1.Denguele (CIV)_min              0.138164         0.052176            2.648           0.008
    L1.Yamoussoukro (CIV)_max          0.034360         0.050023            0.687           0.492
    L1.Comoe (CIV)_min                 0.148475         0.113423            1.309           0.191
    L1.Prod                           -0.000001         0.000000           -3.413           0.001
    L2.Cote D'Ivoire_avg               0.067813         0.121036            0.560           0.575
    L2.Woroba (CIV)_min               -0.042231         0.057552           -0.734           0.463
    L2.Bas-Sassandra (CIV)_min         0.057330         0.117079            0.490           0.624
    L2.Abidjan (CIV)_min              -0.014422         0.109611           -0.132           0.895
    L2.Bas-Sassandra (CIV)_avg        -0.121560         0.097947           -1.241           0.215
    L2.Denguele (CIV)_min              0.063618         0.051594            1.233           0.218
    L2.Yamoussoukro (CIV)_max         -0.004906         0.049939           -0.098           0.922
    L2.Comoe (CIV)_min                -0.051766         0.113904           -0.454           0.649
    L2.Prod                            0.000000         0.000000            0.510           0.610
    L3.Cote D'Ivoire_avg              -0.160458         0.120490           -1.332           0.183
    L3.Woroba (CIV)_min                0.144372         0.057391            2.516           0.012
    L3.Bas-Sassandra (CIV)_min        -0.081085         0.118107           -0.687           0.492
    L3.Abidjan (CIV)_min               0.051414         0.110895            0.464           0.643
    L3.Bas-Sassandra (CIV)_avg         0.176236         0.097108            1.815           0.070
    L3.Denguele (CIV)_min             -0.174088         0.051357           -3.390           0.001
    L3.Yamoussoukro (CIV)_max          0.004986         0.049699            0.100           0.920
    L3.Comoe (CIV)_min                 0.025790         0.114447            0.225           0.822
    L3.Prod                           -0.000000         0.000000           -0.379           0.705
    L4.Cote D'Ivoire_avg              -0.006834         0.120276           -0.057           0.955
    L4.Woroba (CIV)_min                0.073376         0.057570            1.275           0.202
    L4.Bas-Sassandra (CIV)_min         0.048671         0.117320            0.415           0.678
    L4.Abidjan (CIV)_min               0.203012         0.108805            1.866           0.062
    L4.Bas-Sassandra (CIV)_avg         0.359547         0.098092            3.665           0.000
    L4.Denguele (CIV)_min              0.020875         0.052087            0.401           0.689
    L4.Yamoussoukro (CIV)_max          0.082052         0.049639            1.653           0.098
    L4.Comoe (CIV)_min                -0.295686         0.114908           -2.573           0.010
    L4.Prod                            0.000000         0.000000            1.253           0.210
    L5.Cote D'Ivoire_avg              -0.465077         0.122260           -3.804           0.000
    L5.Woroba (CIV)_min                0.171045         0.056486            3.028           0.002
    L5.Bas-Sassandra (CIV)_min         0.050266         0.118058            0.426           0.670
    L5.Abidjan (CIV)_min              -0.052887         0.106843           -0.495           0.621
    L5.Bas-Sassandra (CIV)_avg         0.429853         0.098800            4.351           0.000
    L5.Denguele (CIV)_min             -0.179222         0.050324           -3.561           0.000
    L5.Yamoussoukro (CIV)_max          0.108158         0.049426            2.188           0.029
    L5.Comoe (CIV)_min                 0.081185         0.115024            0.706           0.480
    L5.Prod                           -0.000000         0.000000           -1.416           0.157
    =============================================================================================
    
    Results for equation Denguele (CIV)_min
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                             -1.255720         3.823652           -0.328           0.743
    L1.Cote D'Ivoire_avg              -0.604176         0.233023           -2.593           0.010
    L1.Woroba (CIV)_min                0.231630         0.110793            2.091           0.037
    L1.Bas-Sassandra (CIV)_min         0.191517         0.219558            0.872           0.383
    L1.Abidjan (CIV)_min               0.244474         0.202234            1.209           0.227
    L1.Bas-Sassandra (CIV)_avg         0.050925         0.184550            0.276           0.783
    L1.Denguele (CIV)_min              0.287731         0.096452            2.983           0.003
    L1.Yamoussoukro (CIV)_max          0.233618         0.092473            2.526           0.012
    L1.Comoe (CIV)_min                -0.217029         0.209673           -1.035           0.301
    L1.Prod                           -0.000000         0.000000           -0.597           0.550
    L2.Cote D'Ivoire_avg              -0.097311         0.223747           -0.435           0.664
    L2.Woroba (CIV)_min                0.144152         0.106390            1.355           0.175
    L2.Bas-Sassandra (CIV)_min         0.092168         0.216431            0.426           0.670
    L2.Abidjan (CIV)_min              -0.345550         0.202625           -1.705           0.088
    L2.Bas-Sassandra (CIV)_avg         0.140410         0.181064            0.775           0.438
    L2.Denguele (CIV)_min             -0.150225         0.095376           -1.575           0.115
    L2.Yamoussoukro (CIV)_max          0.042552         0.092316            0.461           0.645
    L2.Comoe (CIV)_min                 0.138389         0.210562            0.657           0.511
    L2.Prod                            0.000001         0.000000            1.212           0.226
    L3.Cote D'Ivoire_avg              -0.102279         0.222738           -0.459           0.646
    L3.Woroba (CIV)_min                0.084871         0.106093            0.800           0.424
    L3.Bas-Sassandra (CIV)_min        -0.278631         0.218332           -1.276           0.202
    L3.Abidjan (CIV)_min               0.241891         0.205000            1.180           0.238
    L3.Bas-Sassandra (CIV)_avg         0.243834         0.179513            1.358           0.174
    L3.Denguele (CIV)_min             -0.059331         0.094938           -0.625           0.532
    L3.Yamoussoukro (CIV)_max          0.046958         0.091874            0.511           0.609
    L3.Comoe (CIV)_min                -0.023433         0.211567           -0.111           0.912
    L3.Prod                           -0.000000         0.000000           -0.641           0.521
    L4.Cote D'Ivoire_avg               0.008764         0.222341            0.039           0.969
    L4.Woroba (CIV)_min                0.186148         0.106423            1.749           0.080
    L4.Bas-Sassandra (CIV)_min        -0.471833         0.216876           -2.176           0.030
    L4.Abidjan (CIV)_min               0.153592         0.201136            0.764           0.445
    L4.Bas-Sassandra (CIV)_avg        -0.212950         0.181333           -1.174           0.240
    L4.Denguele (CIV)_min              0.169500         0.096288            1.760           0.078
    L4.Yamoussoukro (CIV)_max          0.059460         0.091763            0.648           0.517
    L4.Comoe (CIV)_min                 0.177391         0.212418            0.835           0.404
    L4.Prod                            0.000000         0.000000            0.380           0.704
    L5.Cote D'Ivoire_avg               0.076261         0.226009            0.337           0.736
    L5.Woroba (CIV)_min               -0.192803         0.104419           -1.846           0.065
    L5.Bas-Sassandra (CIV)_min        -0.229377         0.218242           -1.051           0.293
    L5.Abidjan (CIV)_min              -0.022337         0.197510           -0.113           0.910
    L5.Bas-Sassandra (CIV)_avg         0.023067         0.182640            0.126           0.899
    L5.Denguele (CIV)_min              0.192808         0.093029            2.073           0.038
    L5.Yamoussoukro (CIV)_max          0.110911         0.091368            1.214           0.225
    L5.Comoe (CIV)_min                 0.250701         0.212632            1.179           0.238
    L5.Prod                            0.000001         0.000000            3.045           0.002
    =============================================================================================
    
    Results for equation Yamoussoukro (CIV)_max
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              1.687543         5.099445            0.331           0.741
    L1.Cote D'Ivoire_avg              -0.327653         0.310773           -1.054           0.292
    L1.Woroba (CIV)_min               -0.120605         0.147760           -0.816           0.414
    L1.Bas-Sassandra (CIV)_min         0.090372         0.292815            0.309           0.758
    L1.Abidjan (CIV)_min               0.202206         0.269710            0.750           0.453
    L1.Bas-Sassandra (CIV)_avg        -0.112620         0.246127           -0.458           0.647
    L1.Denguele (CIV)_min              0.278457         0.128634            2.165           0.030
    L1.Yamoussoukro (CIV)_max          0.234073         0.123327            1.898           0.058
    L1.Comoe (CIV)_min                -0.020858         0.279632           -0.075           0.941
    L1.Prod                           -0.000001         0.000000           -2.437           0.015
    L2.Cote D'Ivoire_avg               0.161069         0.298402            0.540           0.589
    L2.Woroba (CIV)_min               -0.087102         0.141888           -0.614           0.539
    L2.Bas-Sassandra (CIV)_min         0.132529         0.288645            0.459           0.646
    L2.Abidjan (CIV)_min              -0.252202         0.270233           -0.933           0.351
    L2.Bas-Sassandra (CIV)_avg        -0.361534         0.241477           -1.497           0.134
    L2.Denguele (CIV)_min              0.106339         0.127199            0.836           0.403
    L2.Yamoussoukro (CIV)_max          0.047863         0.123118            0.389           0.697
    L2.Comoe (CIV)_min                 0.087508         0.280818            0.312           0.755
    L2.Prod                            0.000000         0.000001            0.480           0.631
    L3.Cote D'Ivoire_avg              -0.366061         0.297056           -1.232           0.218
    L3.Woroba (CIV)_min                0.318037         0.141492            2.248           0.025
    L3.Bas-Sassandra (CIV)_min        -0.120961         0.291180           -0.415           0.678
    L3.Abidjan (CIV)_min               0.148963         0.273400            0.545           0.586
    L3.Bas-Sassandra (CIV)_avg         0.256782         0.239409            1.073           0.283
    L3.Denguele (CIV)_min             -0.347045         0.126615           -2.741           0.006
    L3.Yamoussoukro (CIV)_max          0.066535         0.122528            0.543           0.587
    L3.Comoe (CIV)_min                -0.074412         0.282158           -0.264           0.792
    L3.Prod                           -0.000000         0.000001           -0.574           0.566
    L4.Cote D'Ivoire_avg               0.195873         0.296528            0.661           0.509
    L4.Woroba (CIV)_min                0.027170         0.141932            0.191           0.848
    L4.Bas-Sassandra (CIV)_min         0.107974         0.289239            0.373           0.709
    L4.Abidjan (CIV)_min               0.654397         0.268246            2.440           0.015
    L4.Bas-Sassandra (CIV)_avg         0.249166         0.241836            1.030           0.303
    L4.Denguele (CIV)_min              0.057012         0.128415            0.444           0.657
    L4.Yamoussoukro (CIV)_max          0.307267         0.122380            2.511           0.012
    L4.Comoe (CIV)_min                -0.719745         0.283294           -2.541           0.011
    L4.Prod                            0.000000         0.000001            0.171           0.864
    L5.Cote D'Ivoire_avg              -0.948241         0.301419           -3.146           0.002
    L5.Woroba (CIV)_min                0.281205         0.139259            2.019           0.043
    L5.Bas-Sassandra (CIV)_min         0.209238         0.291060            0.719           0.472
    L5.Abidjan (CIV)_min              -0.119240         0.263411           -0.453           0.651
    L5.Bas-Sassandra (CIV)_avg         0.838126         0.243580            3.441           0.001
    L5.Denguele (CIV)_min             -0.353935         0.124069           -2.853           0.004
    L5.Yamoussoukro (CIV)_max          0.304101         0.121854            2.496           0.013
    L5.Comoe (CIV)_min                 0.097877         0.283578            0.345           0.730
    L5.Prod                           -0.000000         0.000000           -0.300           0.764
    =============================================================================================
    
    Results for equation Comoe (CIV)_min
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                              8.949519         2.621355            3.414           0.001
    L1.Cote D'Ivoire_avg              -0.124145         0.159752           -0.777           0.437
    L1.Woroba (CIV)_min                0.058871         0.075956            0.775           0.438
    L1.Bas-Sassandra (CIV)_min        -0.003147         0.150521           -0.021           0.983
    L1.Abidjan (CIV)_min               0.098108         0.138644            0.708           0.479
    L1.Bas-Sassandra (CIV)_avg        -0.007754         0.126521           -0.061           0.951
    L1.Denguele (CIV)_min              0.023009         0.066124            0.348           0.728
    L1.Yamoussoukro (CIV)_max          0.060494         0.063396            0.954           0.340
    L1.Comoe (CIV)_min                 0.253831         0.143744            1.766           0.077
    L1.Prod                           -0.000000         0.000000           -1.889           0.059
    L2.Cote D'Ivoire_avg              -0.025037         0.153393           -0.163           0.870
    L2.Woroba (CIV)_min                0.035264         0.072937            0.483           0.629
    L2.Bas-Sassandra (CIV)_min        -0.135697         0.148377           -0.915           0.360
    L2.Abidjan (CIV)_min              -0.204869         0.138912           -1.475           0.140
    L2.Bas-Sassandra (CIV)_avg        -0.089918         0.124131           -0.724           0.469
    L2.Denguele (CIV)_min             -0.044746         0.065386           -0.684           0.494
    L2.Yamoussoukro (CIV)_max          0.055988         0.063289            0.885           0.376
    L2.Comoe (CIV)_min                 0.257535         0.144353            1.784           0.074
    L2.Prod                            0.000000         0.000000            1.205           0.228
    L3.Cote D'Ivoire_avg               0.025441         0.152701            0.167           0.868
    L3.Woroba (CIV)_min                0.146551         0.072734            2.015           0.044
    L3.Bas-Sassandra (CIV)_min        -0.210201         0.149680           -1.404           0.160
    L3.Abidjan (CIV)_min               0.100263         0.140540            0.713           0.476
    L3.Bas-Sassandra (CIV)_avg         0.045845         0.123068            0.373           0.710
    L3.Denguele (CIV)_min             -0.110812         0.065086           -1.703           0.089
    L3.Yamoussoukro (CIV)_max          0.034190         0.062985            0.543           0.587
    L3.Comoe (CIV)_min                -0.055447         0.145042           -0.382           0.702
    L3.Prod                           -0.000000         0.000000           -0.621           0.534
    L4.Cote D'Ivoire_avg              -0.378472         0.152429           -2.483           0.013
    L4.Woroba (CIV)_min                0.133734         0.072960            1.833           0.067
    L4.Bas-Sassandra (CIV)_min         0.147411         0.148682            0.991           0.321
    L4.Abidjan (CIV)_min               0.033387         0.137891            0.242           0.809
    L4.Bas-Sassandra (CIV)_avg         0.161463         0.124315            1.299           0.194
    L4.Denguele (CIV)_min              0.159996         0.066011            2.424           0.015
    L4.Yamoussoukro (CIV)_max          0.141591         0.062909            2.251           0.024
    L4.Comoe (CIV)_min                -0.040996         0.145626           -0.282           0.778
    L4.Prod                            0.000000         0.000000            0.718           0.473
    L5.Cote D'Ivoire_avg              -0.144206         0.154943           -0.931           0.352
    L5.Woroba (CIV)_min               -0.048070         0.071586           -0.671           0.502
    L5.Bas-Sassandra (CIV)_min        -0.110077         0.149618           -0.736           0.462
    L5.Abidjan (CIV)_min              -0.016910         0.135406           -0.125           0.901
    L5.Bas-Sassandra (CIV)_avg        -0.041613         0.125211           -0.332           0.740
    L5.Denguele (CIV)_min              0.074720         0.063777            1.172           0.241
    L5.Yamoussoukro (CIV)_max          0.118564         0.062638            1.893           0.058
    L5.Comoe (CIV)_min                 0.160439         0.145773            1.101           0.271
    L5.Prod                            0.000000         0.000000            0.034           0.973
    =============================================================================================
    
    Results for equation Prod
    =============================================================================================
                                    coefficient       std. error           t-stat            prob
    ---------------------------------------------------------------------------------------------
    const                         425869.539105    540852.274792            0.787           0.431
    L1.Cote D'Ivoire_avg          -12024.518677     32960.852001           -0.365           0.715
    L1.Woroba (CIV)_min             -696.406300     15671.617174           -0.044           0.965
    L1.Bas-Sassandra (CIV)_min      8150.851078     31056.220905            0.262           0.793
    L1.Abidjan (CIV)_min          -13548.401316     28605.759193           -0.474           0.636
    L1.Bas-Sassandra (CIV)_avg    -19079.035583     26104.425954           -0.731           0.465
    L1.Denguele (CIV)_min          -1316.020097     13643.027882           -0.096           0.923
    L1.Yamoussoukro (CIV)_max       2936.826319     13080.220969            0.225           0.822
    L1.Comoe (CIV)_min             15058.285239     29658.030364            0.508           0.612
    L1.Prod                            0.896520         0.044923           19.957           0.000
    L2.Cote D'Ivoire_avg           63288.134777     31648.844565            2.000           0.046
    L2.Woroba (CIV)_min           -15093.552097     15048.828766           -1.003           0.316
    L2.Bas-Sassandra (CIV)_min     -8167.892197     30614.009219           -0.267           0.790
    L2.Abidjan (CIV)_min            7447.473155     28661.165308            0.260           0.795
    L2.Bas-Sassandra (CIV)_avg    -26345.770543     25611.327477           -1.029           0.304
    L2.Denguele (CIV)_min          -2482.876021     13490.895090           -0.184           0.854
    L2.Yamoussoukro (CIV)_max     -15111.727896     13058.035882           -1.157           0.247
    L2.Comoe (CIV)_min            -14074.864660     29783.793341           -0.473           0.637
    L2.Prod                           -0.007452         0.060635           -0.123           0.902
    L3.Cote D'Ivoire_avg            8908.709174     31506.072227            0.283           0.777
    L3.Woroba (CIV)_min           -16588.484298     15006.826881           -1.105           0.269
    L3.Bas-Sassandra (CIV)_min     26245.731868     30882.813747            0.850           0.395
    L3.Abidjan (CIV)_min           13767.249930     28997.046318            0.475           0.635
    L3.Bas-Sassandra (CIV)_avg     37680.672533     25391.987087            1.484           0.138
    L3.Denguele (CIV)_min          17935.022503     13428.927480            1.336           0.182
    L3.Yamoussoukro (CIV)_max     -21139.030637     12995.487506           -1.627           0.104
    L3.Comoe (CIV)_min            -36975.757201     29925.928605           -1.236           0.217
    L3.Prod                            0.004282         0.060441            0.071           0.944
    L4.Cote D'Ivoire_avg           27885.606858     31450.010561            0.887           0.375
    L4.Woroba (CIV)_min            -3115.917743     15053.426024           -0.207           0.836
    L4.Bas-Sassandra (CIV)_min    -20041.138730     30676.929988           -0.653           0.514
    L4.Abidjan (CIV)_min           26780.804829     28450.455669            0.941           0.347
    L4.Bas-Sassandra (CIV)_avg     -7470.913951     25649.354246           -0.291           0.771
    L4.Denguele (CIV)_min          -4154.573726     13619.815884           -0.305           0.760
    L4.Yamoussoukro (CIV)_max      -9117.012409     12979.732392           -0.702           0.482
    L4.Comoe (CIV)_min            -15112.937536     30046.407191           -0.503           0.615
    L4.Prod                           -0.004388         0.060419           -0.073           0.942
    L5.Cote D'Ivoire_avg           38346.284273     31968.775823            1.199           0.230
    L5.Woroba (CIV)_min            -7419.829435     14769.998069           -0.502           0.615
    L5.Bas-Sassandra (CIV)_min    -13253.673949     30870.077734           -0.429           0.668
    L5.Abidjan (CIV)_min          -18230.106301     27937.614446           -0.653           0.514
    L5.Bas-Sassandra (CIV)_avg    -14599.091221     25834.293862           -0.565           0.572
    L5.Denguele (CIV)_min         -10204.234664     13158.905755           -0.775           0.438
    L5.Yamoussoukro (CIV)_max      -2674.493407     12923.905480           -0.207           0.836
    L5.Comoe (CIV)_min             16418.723008     30076.616352            0.546           0.585
    L5.Prod                           -0.038703         0.046657           -0.830           0.407
    =============================================================================================
    
    Correlation matrix of residuals
                               Cote D'Ivoire_avg  Woroba (CIV)_min  Bas-Sassandra (CIV)_min  Abidjan (CIV)_min  Bas-Sassandra (CIV)_avg  Denguele (CIV)_min  Yamoussoukro (CIV)_max  Comoe (CIV)_min      Prod
    Cote D'Ivoire_avg                   1.000000          0.578091                 0.643499           0.755209                 0.751687            0.560647                0.767267         0.665248 -0.024194
    Woroba (CIV)_min                    0.578091          1.000000                 0.585017           0.557257                 0.070436            0.877217                0.027055         0.677238  0.022673
    Bas-Sassandra (CIV)_min             0.643499          0.585017                 1.000000           0.833346                 0.455891            0.470915                0.287440         0.894641 -0.014924
    Abidjan (CIV)_min                   0.755209          0.557257                 0.833346           1.000000                 0.516691            0.478005                0.447825         0.889692 -0.016177
    Bas-Sassandra (CIV)_avg             0.751687          0.070436                 0.455891           0.516691                 1.000000            0.098775                0.829410         0.345206 -0.047917
    Denguele (CIV)_min                  0.560647          0.877217                 0.470915           0.478005                 0.098775            1.000000                0.061907         0.552155  0.030781
    Yamoussoukro (CIV)_max              0.767267          0.027055                 0.287440           0.447825                 0.829410            0.061907                1.000000         0.249443 -0.019663
    Comoe (CIV)_min                     0.665248          0.677238                 0.894641           0.889692                 0.345206            0.552155                0.249443         1.000000 -0.011871
    Prod                               -0.024194          0.022673                -0.014924          -0.016177                -0.047917            0.030781               -0.019663        -0.011871  1.000000
    
    
    
    


```python
# Get the lag order
lag_order = results.k_ar
print(lag_order)  #> 4

# Input data for forecasting
forecast_input = train.values[-lag_order:]
forecast_input
```

    5
    




    array([[3.04571429e+01, 2.20428571e+01, 2.21571429e+01, 2.44142857e+01,
            2.81428571e+01, 2.23428571e+01, 3.88714286e+01, 2.23714286e+01,
            1.24500000e+06],
           [2.82428571e+01, 1.94857143e+01, 2.21857143e+01, 2.35000000e+01,
            2.67714286e+01, 1.99428571e+01, 3.62857143e+01, 2.16714286e+01,
            1.24500000e+06],
           [2.76428571e+01, 2.04428571e+01, 2.21428571e+01, 2.35714286e+01,
            2.62000000e+01, 1.99571429e+01, 3.44428571e+01, 2.25142857e+01,
            1.26900000e+06],
           [2.90428571e+01, 2.19142857e+01, 2.19857143e+01, 2.39285714e+01,
            2.64142857e+01, 2.19285714e+01, 3.53714286e+01, 2.26714286e+01,
            1.26900000e+06],
           [2.79857143e+01, 2.21428571e+01, 2.22714286e+01, 2.35142857e+01,
            2.61714286e+01, 2.15857143e+01, 3.31000000e+01, 2.28714286e+01,
            1.31100000e+06]])




```python
fc = results.forecast(y=forecast_input, steps=nobs)
df_forecast = pd.DataFrame(fc, index=dfinal1.index[-nobs:], columns=dfinal1.columns + '_forecast')
df_forecast
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_avg_forecast</th>
      <th>Woroba (CIV)_min_forecast</th>
      <th>Bas-Sassandra (CIV)_min_forecast</th>
      <th>Abidjan (CIV)_min_forecast</th>
      <th>Bas-Sassandra (CIV)_avg_forecast</th>
      <th>Denguele (CIV)_min_forecast</th>
      <th>Yamoussoukro (CIV)_max_forecast</th>
      <th>Comoe (CIV)_min_forecast</th>
      <th>Prod_forecast</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2016-06-05</td>
      <td>28.222154</td>
      <td>20.537035</td>
      <td>21.861029</td>
      <td>23.465534</td>
      <td>26.396133</td>
      <td>20.708272</td>
      <td>35.153073</td>
      <td>22.144776</td>
      <td>1.328304e+06</td>
    </tr>
    <tr>
      <td>2016-06-12</td>
      <td>27.341011</td>
      <td>20.755122</td>
      <td>21.710672</td>
      <td>23.108967</td>
      <td>25.650428</td>
      <td>20.612037</td>
      <td>33.782256</td>
      <td>22.003759</td>
      <td>1.282398e+06</td>
    </tr>
    <tr>
      <td>2016-06-19</td>
      <td>27.976946</td>
      <td>20.883008</td>
      <td>21.579290</td>
      <td>23.192113</td>
      <td>26.130107</td>
      <td>20.987325</td>
      <td>34.711140</td>
      <td>21.903325</td>
      <td>1.316832e+06</td>
    </tr>
    <tr>
      <td>2016-06-26</td>
      <td>27.052564</td>
      <td>21.558737</td>
      <td>21.627061</td>
      <td>22.989834</td>
      <td>25.191516</td>
      <td>21.299060</td>
      <td>32.228374</td>
      <td>22.050336</td>
      <td>1.294275e+06</td>
    </tr>
    <tr>
      <td>2016-07-03</td>
      <td>27.319507</td>
      <td>20.627653</td>
      <td>21.507881</td>
      <td>22.948805</td>
      <td>25.740992</td>
      <td>20.494322</td>
      <td>33.647403</td>
      <td>21.732966</td>
      <td>1.286634e+06</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>2018-12-09</td>
      <td>27.251427</td>
      <td>20.195905</td>
      <td>21.615142</td>
      <td>23.050453</td>
      <td>25.983970</td>
      <td>19.913595</td>
      <td>34.275652</td>
      <td>21.857643</td>
      <td>9.514439e+05</td>
    </tr>
    <tr>
      <td>2018-12-16</td>
      <td>27.253842</td>
      <td>20.191534</td>
      <td>21.615184</td>
      <td>23.051035</td>
      <td>25.988280</td>
      <td>19.908958</td>
      <td>34.284558</td>
      <td>21.856936</td>
      <td>9.501978e+05</td>
    </tr>
    <tr>
      <td>2018-12-23</td>
      <td>27.256867</td>
      <td>20.187666</td>
      <td>21.615370</td>
      <td>23.051923</td>
      <td>25.992816</td>
      <td>19.904959</td>
      <td>34.294101</td>
      <td>21.856477</td>
      <td>9.490687e+05</td>
    </tr>
    <tr>
      <td>2018-12-30</td>
      <td>27.260544</td>
      <td>20.184302</td>
      <td>21.615698</td>
      <td>23.053130</td>
      <td>25.997597</td>
      <td>19.901614</td>
      <td>34.304350</td>
      <td>21.856269</td>
      <td>9.480667e+05</td>
    </tr>
    <tr>
      <td>2019-01-06</td>
      <td>27.264810</td>
      <td>20.181499</td>
      <td>21.616155</td>
      <td>23.054631</td>
      <td>26.002536</td>
      <td>19.898992</td>
      <td>34.315130</td>
      <td>21.856305</td>
      <td>9.471985e+05</td>
    </tr>
  </tbody>
</table>
<p>136 rows × 9 columns</p>
</div>




```python
df_forecast.dtypes
```




    Cote D'Ivoire_avg_forecast          float64
    Woroba (CIV)_min_forecast           float64
    Bas-Sassandra (CIV)_min_forecast    float64
    Abidjan (CIV)_min_forecast          float64
    Bas-Sassandra (CIV)_avg_forecast    float64
    Denguele (CIV)_min_forecast         float64
    Yamoussoukro (CIV)_max_forecast     float64
    Comoe (CIV)_min_forecast            float64
    Prod_forecast                       float64
    dtype: object




```python
df_forecast['Prod_forecast'] = df_forecast['Prod_forecast'].round()
df_forecast
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cote D'Ivoire_avg_forecast</th>
      <th>Woroba (CIV)_min_forecast</th>
      <th>Bas-Sassandra (CIV)_min_forecast</th>
      <th>Abidjan (CIV)_min_forecast</th>
      <th>Bas-Sassandra (CIV)_avg_forecast</th>
      <th>Denguele (CIV)_min_forecast</th>
      <th>Yamoussoukro (CIV)_max_forecast</th>
      <th>Comoe (CIV)_min_forecast</th>
      <th>Prod_forecast</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2016-06-05</td>
      <td>28.222154</td>
      <td>20.537035</td>
      <td>21.861029</td>
      <td>23.465534</td>
      <td>26.396133</td>
      <td>20.708272</td>
      <td>35.153073</td>
      <td>22.144776</td>
      <td>1328304.0</td>
    </tr>
    <tr>
      <td>2016-06-12</td>
      <td>27.341011</td>
      <td>20.755122</td>
      <td>21.710672</td>
      <td>23.108967</td>
      <td>25.650428</td>
      <td>20.612037</td>
      <td>33.782256</td>
      <td>22.003759</td>
      <td>1282398.0</td>
    </tr>
    <tr>
      <td>2016-06-19</td>
      <td>27.976946</td>
      <td>20.883008</td>
      <td>21.579290</td>
      <td>23.192113</td>
      <td>26.130107</td>
      <td>20.987325</td>
      <td>34.711140</td>
      <td>21.903325</td>
      <td>1316832.0</td>
    </tr>
    <tr>
      <td>2016-06-26</td>
      <td>27.052564</td>
      <td>21.558737</td>
      <td>21.627061</td>
      <td>22.989834</td>
      <td>25.191516</td>
      <td>21.299060</td>
      <td>32.228374</td>
      <td>22.050336</td>
      <td>1294275.0</td>
    </tr>
    <tr>
      <td>2016-07-03</td>
      <td>27.319507</td>
      <td>20.627653</td>
      <td>21.507881</td>
      <td>22.948805</td>
      <td>25.740992</td>
      <td>20.494322</td>
      <td>33.647403</td>
      <td>21.732966</td>
      <td>1286634.0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>2018-12-09</td>
      <td>27.251427</td>
      <td>20.195905</td>
      <td>21.615142</td>
      <td>23.050453</td>
      <td>25.983970</td>
      <td>19.913595</td>
      <td>34.275652</td>
      <td>21.857643</td>
      <td>951444.0</td>
    </tr>
    <tr>
      <td>2018-12-16</td>
      <td>27.253842</td>
      <td>20.191534</td>
      <td>21.615184</td>
      <td>23.051035</td>
      <td>25.988280</td>
      <td>19.908958</td>
      <td>34.284558</td>
      <td>21.856936</td>
      <td>950198.0</td>
    </tr>
    <tr>
      <td>2018-12-23</td>
      <td>27.256867</td>
      <td>20.187666</td>
      <td>21.615370</td>
      <td>23.051923</td>
      <td>25.992816</td>
      <td>19.904959</td>
      <td>34.294101</td>
      <td>21.856477</td>
      <td>949069.0</td>
    </tr>
    <tr>
      <td>2018-12-30</td>
      <td>27.260544</td>
      <td>20.184302</td>
      <td>21.615698</td>
      <td>23.053130</td>
      <td>25.997597</td>
      <td>19.901614</td>
      <td>34.304350</td>
      <td>21.856269</td>
      <td>948067.0</td>
    </tr>
    <tr>
      <td>2019-01-06</td>
      <td>27.264810</td>
      <td>20.181499</td>
      <td>21.616155</td>
      <td>23.054631</td>
      <td>26.002536</td>
      <td>19.898992</td>
      <td>34.315130</td>
      <td>21.856305</td>
      <td>947199.0</td>
    </tr>
  </tbody>
</table>
<p>136 rows × 9 columns</p>
</div>




```python
from statsmodels.tsa.stattools import acf
def forecast_accuracy(pred, valid):
    mape = np.mean(np.abs(pred - valid)/np.abs(valid))  # MAPE
    me = np.mean(pred - valid)             # ME
    mae = np.mean(np.abs(pred - valid))    # MAE
    mpe = np.mean((pred - valid)/valid)   # MPE
    rmse = np.mean((pred - valid)**2)**.5  # RMSE
    corr = np.corrcoef(pred, valid)[0,1]   # corr
    mins = np.amin(np.hstack([pred[:,None], 
                              valid[:,None]]), axis=1)
    maxs = np.amax(np.hstack([pred[:,None], 
                              valid[:,None]]), axis=1)
    minmax = 1 - np.mean(mins/maxs)             # minmax
    return({'mape':mape, 'me':me, 'mae': mae, 
            'mpe': mpe, 'rmse':rmse, 'corr':corr, 'minmax':minmax})


```


```python
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Cote D'Ivoire_avg")
accuracy_prod = forecast_accuracy(df_forecast["Cote D'Ivoire_avg_forecast"].values, valid["Cote D'Ivoire_avg"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Woroba (CIV)_min")
accuracy_prod = forecast_accuracy(df_forecast["Woroba (CIV)_min_forecast"].values, valid["Woroba (CIV)_min"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))

def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Bas-Sassandra (CIV)_min")
accuracy_prod = forecast_accuracy(df_forecast["Bas-Sassandra (CIV)_min_forecast"].values, valid["Bas-Sassandra (CIV)_min"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Abidjan (CIV)_min")
accuracy_prod = forecast_accuracy(df_forecast["Abidjan (CIV)_min_forecast"].values, valid["Abidjan (CIV)_min"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Bas-Sassandra (CIV)_avg")
accuracy_prod = forecast_accuracy(df_forecast["Bas-Sassandra (CIV)_avg_forecast"].values, valid["Bas-Sassandra (CIV)_avg"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Denguele (CIV)_min")
accuracy_prod = forecast_accuracy(df_forecast["Denguele (CIV)_min_forecast"].values, valid["Denguele (CIV)_min"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Yamoussoukro (CIV)_max")
accuracy_prod = forecast_accuracy(df_forecast["Yamoussoukro (CIV)_max_forecast"].values, valid["Yamoussoukro (CIV)_max"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Comoe (CIV)_min")
accuracy_prod = forecast_accuracy(df_forecast["Comoe (CIV)_min_forecast"].values, valid["Comoe (CIV)_min"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
def adjust(val, length= 6): return str(val).ljust(length)
print("Forecast Accuracy of: Prod_forecast")
accuracy_prod = forecast_accuracy(df_forecast["Prod_forecast"].values, valid["Prod"])
for k, v in accuracy_prod.items():
    print(adjust(k), ': ', round(v,4))
    
```

    Forecast Accuracy of: Cote D'Ivoire_avg
    mape   :  0.0414
    me     :  -0.206
    mae    :  1.1438
    mpe    :  -0.005
    rmse   :  1.3711
    corr   :  0.3733
    minmax :  0.0404
    Forecast Accuracy of: Woroba (CIV)_min
    mape   :  0.0714
    me     :  0.488
    mae    :  1.2436
    mpe    :  0.0364
    rmse   :  1.9278
    corr   :  0.2957
    minmax :  0.0605
    Forecast Accuracy of: Bas-Sassandra (CIV)_min
    mape   :  0.0189
    me     :  0.0601
    mae    :  0.4042
    mpe    :  0.0034
    rmse   :  0.5107
    corr   :  0.1746
    minmax :  0.0185
    Forecast Accuracy of: Abidjan (CIV)_min
    mape   :  0.0261
    me     :  0.098
    mae    :  0.5958
    mpe    :  0.0053
    rmse   :  0.7277
    corr   :  0.298
    minmax :  0.0255
    Forecast Accuracy of: Bas-Sassandra (CIV)_avg
    mape   :  0.0365
    me     :  -0.2965
    mae    :  0.9615
    mpe    :  -0.0095
    rmse   :  1.1262
    corr   :  0.4291
    minmax :  0.0358
    Forecast Accuracy of: Denguele (CIV)_min
    mape   :  0.0635
    me     :  0.2524
    mae    :  1.1908
    mpe    :  0.0204
    rmse   :  1.6461
    corr   :  0.2688
    minmax :  0.0579
    Forecast Accuracy of: Yamoussoukro (CIV)_max
    mape   :  0.0562
    me     :  -1.1224
    mae    :  2.0328
    mpe    :  -0.0279
    rmse   :  2.4512
    corr   :  0.4779
    minmax :  0.0553
    Forecast Accuracy of: Comoe (CIV)_min
    mape   :  0.0264
    me     :  0.141
    mae    :  0.562
    mpe    :  0.0077
    rmse   :  0.76
    corr   :  0.1154
    minmax :  0.0254
    Forecast Accuracy of: Prod_forecast
    mape   :  1.0835
    me     :  -284411.4191
    mae    :  524068.125
    mpe    :  0.5894
    rmse   :  596531.2773
    corr   :  0.3333
    minmax :  0.3764
    


```python
fig, axes = plt.subplots(nrows=int(len(dfinal1.columns)/2), ncols=2, dpi=150, figsize=(10,10))
for i, (col,ax) in enumerate(zip(dfinal1.columns, axes.flatten())):
    df_forecast[col+'_forecast'].head(10).plot(legend=True, ax=ax).autoscale(axis='x',tight=True)
    valid[col][-nobs:].head(10).plot(legend=True, ax=ax);
    ax.set_title(col + ": Forecast vs Actuals")
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    ax.spines["top"].set_alpha(0)
    ax.tick_params(labelsize=6)

plt.tight_layout();
```


![png](output_46_0.png)

